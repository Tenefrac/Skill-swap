<?php
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM users WHERE id = $user_id";
$user_result = $conn->query($user_query);
$user = $user_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - SkillSwap</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="container">
        <div class="logo">SkillSwap</div>
        <ul class="nav-links">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="dashboard.php#marketplace">Marketplace</a></li>
            <li><a href="messages.php" class="nav-active">Messages</a></li>
            <li><span class="user-info">👤 <?php echo htmlspecialchars($user['name']); ?> • <?php echo $user['credits']; ?> Credits</span></li>
            <li><a href="logout.php" class="btn-logout">Logout</a></li>
        </ul>
    </div>
</nav>

<!-- HEADER -->
<header class="dashboard-header">
    <div class="container">
        <h1>📬 Messages</h1>
        <p>Connect and communicate with other SkillSwap members</p>
    </div>
</header>

<!-- MESSAGES SECTION -->
<section class="messages-section">
    <div class="container">
        <div class="messages-container">
            <div class="messages-list">
                <h2>Your Conversations</h2>
                <div class="empty-state">
                    <p>No messages yet. Start by exploring the <a href="dashboard.php#marketplace">marketplace →</a></p>
                </div>
            </div>
            
            <div class="message-detail">
                <h2>💬 Start a Conversation</h2>
                <p class="empty-state">Select a conversation to view messages or start a new one from the marketplace.</p>
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <p>&copy; 2026 SkillSwap. All rights reserved. | Made with ❤️ for Skill Exchange</p>
    </div>
</footer>

</body>
</html>