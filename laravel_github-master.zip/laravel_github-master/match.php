<?php
include 'config.php';

$keyword = $_GET['keyword'];

$sql = "SELECT * FROM services WHERE category LIKE '%$keyword%'";
$result = $conn->query($sql);

echo "<h3>Matched Services:</h3>";

while ($row = $result->fetch_assoc()) {
    echo "Title: " . $row['title'] . "<br>";
    echo "Category: " . $row['category'] . "<br><br>";
}
?>