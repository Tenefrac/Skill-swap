<?php
session_start();
include 'config.php';

$reviewer = $_SESSION['user']['id'];
$reviewed = $_POST['reviewed'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];

$conn->query("INSERT INTO reviews (reviewer_id, reviewed_id, rating, comment)
              VALUES ('$reviewer', '$reviewed', '$rating', '$comment')");

echo "Review submitted!";
?>