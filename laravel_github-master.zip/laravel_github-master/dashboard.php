<?php
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php#login");
    exit();
}

// Get user info
$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM users WHERE id = $user_id";
$user_result = $conn->query($user_query);
$user = $user_result->fetch_assoc();

// Handle service posting
$success_message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['post_service'])) {
    $title = isset($_POST['title']) ? $conn->real_escape_string($_POST['title']) : '';
    $category = isset($_POST['category']) ? $conn->real_escape_string($_POST['category']) : '';
    $type = isset($_POST['type']) ? $conn->real_escape_string($_POST['type']) : '';
    $description = isset($_POST['description']) ? $conn->real_escape_string($_POST['description']) : '';
    
    if (!empty($title) && !empty($category) && !empty($type) && !empty($description)) {
        $insert_sql = "INSERT INTO services (user_id, title, category, type, description) 
                      VALUES ('$user_id', '$title', '$category', '$type', '$description')";
        if ($conn->query($insert_sql)) {
            $success_message = "Service posted successfully!";
        }
    }
}

// Handle service deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_service'])) {
    $service_id = isset($_POST['service_id']) ? (int)$_POST['service_id'] : 0;
    if ($service_id > 0) {
        $delete_sql = "DELETE FROM services WHERE id = $service_id AND user_id = $user_id";
        if ($conn->query($delete_sql)) {
            $success_message = "Service deleted successfully!";
        }
    }
}

// Handle service editing
$edit_service = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $edit_query = "SELECT * FROM services WHERE id = $edit_id AND user_id = $user_id";
    $edit_result = $conn->query($edit_query);
    if ($edit_result->num_rows > 0) {
        $edit_service = $edit_result->fetch_assoc();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_service'])) {
    $service_id = isset($_POST['service_id']) ? (int)$_POST['service_id'] : 0;
    $title = isset($_POST['title']) ? $conn->real_escape_string($_POST['title']) : '';
    $category = isset($_POST['category']) ? $conn->real_escape_string($_POST['category']) : '';
    $type = isset($_POST['type']) ? $conn->real_escape_string($_POST['type']) : '';
    $description = isset($_POST['description']) ? $conn->real_escape_string($_POST['description']) : '';
    
    if ($service_id > 0 && !empty($title) && !empty($category) && !empty($type) && !empty($description)) {
        $update_sql = "UPDATE services SET title='$title', category='$category', type='$type', description='$description' 
                      WHERE id=$service_id AND user_id=$user_id";
        if ($conn->query($update_sql)) {
            $success_message = "Service updated successfully!";
            header("Location: dashboard.php");
            exit();
        }
    }
}

// Get user's services
$services_query = "SELECT * FROM services WHERE user_id = $user_id ORDER BY created_at DESC";
$services_result = $conn->query($services_query);

// Get marketplace services
$marketplace_query = "SELECT s.*, u.name FROM services s 
                     JOIN users u ON s.user_id = u.id 
                     WHERE s.user_id != $user_id ORDER BY s.created_at DESC LIMIT 12";
$marketplace_result = $conn->query($marketplace_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkillSwap - Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="container">
        <div class="logo">SkillSwap</div>
        <ul class="nav-links">
            <li><a href="#dashboard" class="nav-active">Dashboard</a></li>
            <li><a href="#marketplace">Marketplace</a></li>
            <li><a href="chat.php">Messages</a></li>
            <li><span class="user-info">👤 <?php echo htmlspecialchars($user['name']); ?> • <?php echo $user['credits']; ?> Credits</span></li>
            <li><a href="logout.php" class="btn-logout">Logout</a></li>
        </ul>
    </div>
</nav>

<!-- DASHBOARD HEADER -->
<header class="dashboard-header">
    <div class="container">
        <h1>Welcome back, <?php echo htmlspecialchars($user['name']); ?>! 👋</h1>
        <p>Manage your skills and connect with the community</p>
    </div>
</header>

<!-- STATS SECTION -->
<section class="stats-section">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">💳</div>
                <h3>Your Credits</h3>
                <p class="stat-number"><?php echo $user['credits']; ?></p>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📝</div>
                <h3>Services Posted</h3>
                <p class="stat-number"><?php echo $services_result->num_rows; ?></p>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⭐</div>
                <h3>Your Rating</h3>
                <p class="stat-number"><?php echo isset($user['rating']) ? number_format($user['rating'], 1) : '5.0'; ?></p>
            </div>
        </div>
    </div>
</section>

<!-- CREATE SERVICE SECTION -->
<section id="dashboard" class="create-service-section">
    <div class="container">
        <h2>📢 <?php echo $edit_service ? 'Edit Service' : 'Post a New Service'; ?></h2>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <div class="service-form-container">
            <form method="POST" class="service-form">
                <?php if ($edit_service): ?>
                    <input type="hidden" name="service_id" value="<?php echo $edit_service['id']; ?>">
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="title">Service Title *</label>
                    <input type="text" id="title" name="title" placeholder="e.g., Learn Guitar Basics" 
                           value="<?php echo $edit_service ? htmlspecialchars($edit_service['title']) : ''; ?>" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="category">Category *</label>
                        <select id="category" name="category" required>
                            <option value="">Select Category</option>
                            <option value="languages" <?php echo ($edit_service && $edit_service['category'] == 'languages') ? 'selected' : ''; ?>>🌍 Languages</option>
                            <option value="music" <?php echo ($edit_service && $edit_service['category'] == 'music') ? 'selected' : ''; ?>>🎵 Music</option>
                            <option value="tech" <?php echo ($edit_service && $edit_service['category'] == 'tech') ? 'selected' : ''; ?>>💻 Technology</option>
                            <option value="fitness" <?php echo ($edit_service && $edit_service['category'] == 'fitness') ? 'selected' : ''; ?>>💪 Fitness</option>
                            <option value="cooking" <?php echo ($edit_service && $edit_service['category'] == 'cooking') ? 'selected' : ''; ?>>🍳 Cooking</option>
                            <option value="art" <?php echo ($edit_service && $edit_service['category'] == 'art') ? 'selected' : ''; ?>>🎨 Art & Design</option>
                            <option value="business" <?php echo ($edit_service && $edit_service['category'] == 'business') ? 'selected' : ''; ?>>📊 Business</option>
                            <option value="other" <?php echo ($edit_service && $edit_service['category'] == 'other') ? 'selected' : ''; ?>>✨ Other</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="type">Type *</label>
                        <select id="type" name="type" required>
                            <option value="">Select Type</option>
                            <option value="offer" <?php echo ($edit_service && $edit_service['type'] == 'offer') ? 'selected' : ''; ?>>🎯 Offer (I can teach this)</option>
                            <option value="request" <?php echo ($edit_service && $edit_service['type'] == 'request') ? 'selected' : ''; ?>>🔍 Request (I want to learn this)</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Description *</label>
                    <textarea id="description" name="description" placeholder="Describe your skill or what you want to learn..." rows="5" required><?php echo $edit_service ? htmlspecialchars($edit_service['description']) : ''; ?></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="submit" name="<?php echo $edit_service ? 'edit_service' : 'post_service'; ?>" class="btn-primary">
                        <?php echo $edit_service ? 'Update Service' : 'Post Service'; ?>
                    </button>
                    <?php if ($edit_service): ?>
                        <a href="dashboard.php" class="btn-secondary">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</section>

<!-- MY SERVICES SECTION -->
<section class="my-services-section">
    <div class="container">
        <h2>📚 Your Services</h2>
        
        <?php if ($services_result->num_rows > 0): ?>
            <div class="services-grid">
                <?php while ($service = $services_result->fetch_assoc()): ?>
                    <div class="service-card">
                        <div class="service-header">
                            <span class="service-type <?php echo $service['type']; ?>">
                                <?php echo $service['type'] == 'offer' ? '🎯 Offer' : '🔍 Request'; ?>
                            </span>
                            <span class="service-category"><?php echo ucfirst($service['category']); ?></span>
                        </div>
                        <h3><?php echo htmlspecialchars($service['title']); ?></h3>
                        <p><?php echo htmlspecialchars(substr($service['description'], 0, 100)); ?>...</p>
                        <div class="service-actions">
                            <a href="?edit=<?php echo $service['id']; ?>#dashboard" class="btn-small">✏️ Edit</a>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this service?')">
                                <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                <button type="submit" name="delete_service" class="btn-small btn-danger">🗑️ Delete</button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="empty-state">No services posted yet. <a href="#dashboard">Create your first service →</a></p>
        <?php endif; ?>
    </div>
</section>

<!-- MARKETPLACE SECTION -->
<section id="marketplace" class="marketplace-section">
    <div class="container">
        <h2>🏪 Marketplace</h2>
        <p class="section-subtitle">Discover skills offered by other members in our community</p>
        
        <?php if ($marketplace_result->num_rows > 0): ?>
            <div class="marketplace-grid">
                <?php while ($service = $marketplace_result->fetch_assoc()): ?>
                    <div class="marketplace-card">
                        <div class="card-header">
                            <span class="service-type <?php echo $service['type']; ?>">
                                <?php echo $service['type'] == 'offer' ? '🎯 Offering' : '🔍 Seeking'; ?>
                            </span>
                        </div>
                        <h3><?php echo htmlspecialchars($service['title']); ?></h3>
                        <p class="provider-name">by <strong><?php echo htmlspecialchars($service['name']); ?></strong></p>
                        <p class="description"><?php echo htmlspecialchars(substr($service['description'], 0, 120)); ?>...</p>
                        <div class="category-badge"><?php echo ucfirst($service['category']); ?></div>
                        <a href="service_details.php?id=<?php echo $service['id']; ?>" class="btn-primary-small">👀 View Details</a>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="empty-state">No services available in the marketplace yet.</p>
        <?php endif; ?>
    </div>
</section>

<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <p>&copy; 2026 SkillSwap. All rights reserved. | Made with ❤️ for Skill Exchange</p>
    </div>
</footer>

</body>
</html>