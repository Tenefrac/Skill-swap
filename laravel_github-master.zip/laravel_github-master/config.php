<?php
$conn = new mysqli("localhost", "root", "", "skillswap");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>