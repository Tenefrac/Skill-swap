<!DOCTYPE html>
<html>
<head>
    <title>SkillSwap - Share Your Skills</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<nav class="navbar">
    <div class="container">
        <div class="logo">SkillSwap</div>
        <ul class="nav-links">
            <li><a href="#features">Features</a></li> 
            <li><a href="#login" class="btn-login">Login</a></li>
        </ul>
    </div>
</nav>

<header class="hero">
    <div class="container">
        <h1>Share Your Skills, Learn New Ones</h1>
        <p>Connect with others and exchange skills in a trusted community</p>
        <a href="#get-started" class="btn-primary">Get Started</a>
    </div>
</header>

<section id="features" class="features">
    <div class="container">
        <h2>How SkillSwap Works</h2>
        <div class="features-grid">
            <div class="feature-card">
                <h3>📝 Create Your Profile</h3>
                <p>Sign up and showcase the skills you want to share with the community</p>
            </div>
            <div class="feature-card">
                <h3>📢 Post Services</h3>
                <p>Offer your skills or request skills you want to learn</p>
            </div>
            <div class="feature-card">
                <h3>🔍 Find Matches</h3>
                <p>Search and connect with people who have complementary skills</p>
            </div>
            <div class="feature-card">
                <h3>🤝 Exchange Skills</h3>
                <p>Learn and teach in a fair, skill-for-skill exchange</p>
            </div>
        </div>
    </div>
</section>

<section id="get-started" class="cta">
    <div class="container">
        <h2>Ready to Get Started?</h2>
        <div class="cta-buttons">
            <a href="register.php" class="btn-primary">Register Now</a>
            <a href="#login" class="btn-secondary">Already a Member? Login</a>
        </div>
    </div>
</section>

<section id="login" class="login-section">
    <div class="container">
        <div class="login-card">
            <h2>Login to Your Account</h2>
            <form action="login.php" method="POST">
                <input type="email" name="email" placeholder="Email" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit" class="btn-primary">Login</button>
            </form>
            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </div>
    </div>
</section>



<footer class="footer">
    <div class="container">
        <p>&copy; 2026 SkillSwap. All rights reserved.</p>
    </div>
</footer>

</body>
</html>