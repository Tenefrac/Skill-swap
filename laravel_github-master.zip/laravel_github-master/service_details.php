<?php
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_query = "SELECT * FROM users WHERE id = $user_id";
$user_result = $conn->query($user_query);
$user = $user_result->fetch_assoc();

// Get service details
$service_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($service_id <= 0) {
    header("Location: dashboard.php");
    exit();
}

$service_query = "SELECT s.*, u.name, u.email FROM services s 
                 JOIN users u ON s.user_id = u.id 
                 WHERE s.id = $service_id";
$service_result = $conn->query($service_query);

if ($service_result->num_rows == 0) {
    header("Location: dashboard.php");
    exit();
}

$service = $service_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($service['title']); ?> - SkillSwap</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="container">
        <div class="logo">SkillSwap</div>
        <ul class="nav-links">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="dashboard.php#marketplace">Marketplace</a></li>
            <li><a href="chat.php">Messages</a></li>
            <li><span class="user-info">👤 <?php echo htmlspecialchars($user['name']); ?> • <?php echo $user['credits']; ?> Credits</span></li>
            <li><a href="logout.php" class="btn-logout">Logout</a></li>
        </ul>
    </div>
</nav>

<!-- HEADER -->
<header class="dashboard-header">
    <div class="container">
        <h1><?php echo htmlspecialchars($service['title']); ?></h1>
        <p>Service Details</p>
    </div>
</header>

<!-- SERVICE DETAILS SECTION -->
<section class="service-details-section">
    <div class="container">
        <div class="service-details-card">
            <div class="service-header">
                <span class="service-type <?php echo $service['type']; ?>">
                    <?php echo $service['type'] == 'offer' ? '🎯 Offering' : '🔍 Seeking'; ?>
                </span>
                <span class="service-category"><?php echo ucfirst($service['category']); ?></span>
            </div>
            
            <h2><?php echo htmlspecialchars($service['title']); ?></h2>
            
            <div class="provider-info">
                <h3>Provider Information</h3>
                <p><strong>Name:</strong> <?php echo htmlspecialchars($service['name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($service['email']); ?></p>
            </div>
            
            <div class="service-description">
                <h3>Description</h3>
                <p><?php echo nl2br(htmlspecialchars($service['description'])); ?></p>
            </div>
            
            <div class="service-meta">
                <p><strong>Posted:</strong> <?php echo date('F j, Y', strtotime($service['created_at'])); ?></p>
            </div>
            
            <div class="service-actions">
                <a href="chat.php" class="btn-primary">💬 Contact Provider</a>
                <a href="dashboard.php#marketplace" class="btn-secondary">← Back to Marketplace</a>
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <p>&copy; 2026 SkillSwap. All rights reserved. | Made with ❤️ for Skill Exchange</p>
    </div>
</footer>

</body>
</html>