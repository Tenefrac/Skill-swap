<?php
include 'config.php';

$user_id = $_POST['user_id'];
$title = $_POST['title'];
$category = $_POST['category'];
$type = $_POST['type'];
$description = $_POST['description'];

$sql = "INSERT INTO services (user_id, title, category, type, description)
        VALUES ('$user_id', '$title', '$category', '$type', '$description')";

if ($conn->query($sql)) {
    echo "Service Created!";
} else {
    echo "Error: " . $conn->error;
}
?>