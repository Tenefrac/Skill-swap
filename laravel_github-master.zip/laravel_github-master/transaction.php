<?php
$conn = new mysqli("localhost", "root", "", "skillswap");

$sender = $_POST['sender'];
$receiver = $_POST['receiver'];
$credits = $_POST['credits'];

// Check sender balance
$check = $conn->query("SELECT credits FROM users WHERE id=$sender");
$data = $check->fetch_assoc();

if ($data['credits'] >= $credits) {

    // Deduct sender
    $conn->query("UPDATE users SET credits = credits - $credits WHERE id=$sender");

    // Add to receiver
    $conn->query("UPDATE users SET credits = credits + $credits WHERE id=$receiver");

    echo "Transaction Successful!";

} else {
    echo "Not enough credits!";
}
?>